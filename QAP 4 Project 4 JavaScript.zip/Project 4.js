const customer = {
  firstName: 'Lorne',
  lastName: 'Prine',
  getFullYear: '2024'
  mailingAddress: "34 Main Street, St. John's, NL",
  phoneNumber: "709-567-8709",
  emailAddress: l.prince@yahoo.com
  birthDate: '2003-05-20'
  gender: 'Male',
  roomPreferences: ["Non-smoking", "Double bed"];
  paymentMethod: "Credit Card",
  checkInDate: "2024-05-09",
  checkOutDate: "2024-05-12",
}

//Method to calculate age of the customer

getAge: function(){
  const today = new Date();
  return today.getFullYear() - this.birthDate;
};

//Method to calculate duration of stay
calculateStayDuration(){
  const checkIn = new Date(this.checkInDate);
  const checkOut = new Date(this.checkOutDate);
  const diffTime = Math.abs(checkOut - checkIn);
  const diffDays = Math.ceil(diffTime/(1000 * 60 * 60 * 24));
  return diffDays;
}
  console.log(html)
  document.body.innerHTML = html
